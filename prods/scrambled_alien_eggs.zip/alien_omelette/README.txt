ALIEN OMELETTE

A game for TO8 by PulkoMandy
Forever 2019 realtime compo

The plot
========

The aliens have invaded your kitchen! And they are laying eggs!
If the eggs touch the ground, they will open and attack you.

However, these eggs do look tasty. What if we cooked scrambled
eggs?

How to play
===========

Press space to start. Then move left or right with your joystick.

Catch all the eggs, whenever you miss one, you lose!

Tip: keep the joystick pressed to move more smoothly.

Have fun!
