/* GFX2mo5 - libraw2mo5.h
 * CloudStrife - 20080921
 * Diffus� sous licence libre CeCILL v2
 * Voire LICENCE
 */

#ifndef LIBRAW2mo5_H
#define LIBRAW2mo5_H 1

unsigned char * raw2mo5(unsigned char *input);

#endif
